<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<ul class="shortcut-buttons-set">

    <li><a class="shortcut-button user" href="<?php echo base_url('admin/users/manage')?>"><span class="png_bg">
					User manager
            </span></a></li>

    <li><a class="shortcut-button email" href="<?php echo base_url('admin/emails/manage')?>"><span class="png_bg">
					Email manager
            </span></a></li>

    <!--li><a class="shortcut-button upload-image" href="#"><span class="png_bg">
					Upload an Image
            </span></a></li>

    <li><a class="shortcut-button add-event" href="#"><span class="png_bg">
					Add an Event
            </span></a></li>

    <li><a class="shortcut-button manage-comments" href="#messages" rel="modal"><span class="png_bg">
					Open Modal
            </span></a></li -->

</ul><!-- End .shortcut-buttons-set -->