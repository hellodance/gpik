
   		<div class="welcome-massage">
        	<h2>A Holistic Transformational Approach for Healthy Lifestyle</h2>
            <p style="color:#666666;">Search <img src="<?=base_url();?>images/arw.png" > Plan <img src="<?=base_url();?>images/arw.png"> Measure <img src="<?=base_url();?>images/arw.png"> Track <img src="<?=base_url();?>images/arw.png"> Improve- An end-to-end free online platform to help improving lifestyle choices</p>
       	</div>
      	<div class="row1 marin1">
        	<div class="box1 pad1">
            	<a href="<?php echo base_url()?>trainer/register" class="ajaxpop_small"> 
				<img src="<?php echo base_url();?>images/thumb01.jpg" width="297" height="297" alt="" />
                <h3>Trainers registration</h3>
				</a>
                <p>Are you a fitness specialist? Looking for more clients and more business? GymPik helps bridging a gap and connects fitness specialists with new clients via an online platform. <a href="<?php echo base_url()?>trainer/register" class="ajaxpop_small hrf" >Register</a> today to promote yourself and connect with new clients </p>
          </div>
        	<div class="box1 pad1">
            	<a href="<?php echo base_url();?>trainer/find" class="ajaxpop_small"> 
				<img src="<?php echo base_url();?>images/thumb02.jpg" width="297" height="297" alt="" />
                <h3>Search trainer </h3>
				</a>
                <p>Expedite your fitness journey with GymPik. Search, Plan, Track and Improve <sup>All Absolutely Free! </sup> . Trainers, Dietician, Pysiotherapist and more, all in one place! Find an expert (Physical Trainer/Dietician/Yoga Instructor/Physiotherapist/ Aerobics/Martial Arts) to help achieving your fitness goal. </p>
          </div>
          	<div class="box1">
				<a href="<?php echo base_url();?>user/register" class="ajaxpop_small"> 
            	<img src="<?php echo base_url();?>images/thumb03.jpg" width="297" height="297" alt="" />
                <h3>Diet suggestions and tracking</h3>
				</a>
                <p>Workout alone is not enough! GymPik provides innovative tools to log your calories intake and helps you track your progress. Do you have a party planned in weekend or family function? No worries, now you would have a flexibility to customize your plan and be on track with your fitness goal</p>
          </div>
        </div>
        <div class="row1 marin2">
        	<div class="today-updates">
                <div style="float:left; margin-right:20px;">
				<img src="<?php echo base_url();?>images/workout.jpg" style="height:270px;" alt="" /></div>
				<p class="gympik_text" align="justify">GymPik provides a holistic approach and offers an online platform to search a desired fitness instructor and keep track of your progress. At GymPik we believe that, working out regularly is only half of the battle won, its equally important to keep track of your calories intake and timely progress to stay motivated. Tracking your health, diet, and fitness can alleviate your motivation and help keep you on course for your target goal. Apart from tracking, at GymPik you will get free tips for Dietician and access to vast network of fitness experts. Whether you are just trying to shed few pounds or training for a triathlon, GymPik can help you day-to-day to keep pushing forward. 
Do you know you can lose up to 300% more weight with a combined diet and exercise plan than either alone! We believe its not a one fit for all magic formula. Everyone is different, hence its important to have a personalize plan focussed on respective aspirations. There is absolute no obligation to provide any credit card or bank account details for registration. <a href="<?php echo base_url();?>user/register" class="ajaxpop_small hrf">Register</a> today to take a first step towards your fitness success.</p>
				<!--<a href="#" class="button marin3"><span>READ MORE</span></a>--> </div>
            </div>
          </div>
