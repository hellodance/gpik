<div id="banner2">
      <div class="rightbanner">
       <h1>Make fintness way of life</h1>
       <p align="justify">
	    <span class="banner-left" style="z-index:0">
	   		<iframe width="500" style="z-index:1" height="315" src="//www.youtube.com/embed/-oEwKFaULXA" frameborder="0" allowfullscreen></iframe>
		</span>
	   Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<br /><br />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
       <div class="readmore"><a href="#"><img src="images/readmore.png" width="79" height="32" style="z-index:0" /></a></div>
        
        </div>
        <div class="midline"></div>
        
  </div>
  	<div id="container">
   		<div class="welcome-massagere">
        	<h2>FITNESS TESTING AND THE<br /> 
PHYSICAL PROFILING OF PLAYERS</h2>
            
       	</div>
      	<div class="row1 marin1-how">
        	<div class="box1 pad1">
            	<img src="images/thumb04.jpg" width="297" height="299" alt="" />
                <h3>Find your trainer </h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
          </div>
        	<div class="box1 pad1">
            	<img src="images/thumb05.jpg" width="297" height="297" alt="" />
                <h3>Know your calories </h3>
                <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete </p>
          </div>
          	<div class="box1">
            	<img src="images/thumb06.jpg" width="297" height="297" alt="" />
                <h3>Track your progress</h3>
                <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti .</p>
          </div>
        </div>
        
        <div class="contantrow">
        <div class="ourtraning">
        <h1>Our Traning</h1>
        <div class="liner"></div>
        <div class="righttext">
          <p align="justify"><span class="floatleft"><img src="images/socilal.jpg" alt="" width="252" height="204" /></span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc tincidunt quis mauris eu sollicitudin. Duis fermentum sapien a interdum luctus. Ut euismod velit sit amet elit scelerisque dictum. Aliquam sed eleifend urna. Pellentesque vehicula magna lectus, egestas varius ligula viverra pharetra. Ut ut dictum elit, quis porttitor ligula. Aenean nec lacinia odio, quis sodales urna. Proin arcu erat, facilisis vel nibh eget, lacinia consectetur turpis. Etiam ligula massa, malesuada ac sem nec, pellentesque tincidunt orci. Duis a viverra odio. In ultrices leo nec cursus iaculis. Suspendisse auctor dictum nisi vel facilisis. Mauris ut sagittis lacus. Morbi eu aliquet ipsum. <br /><br />Nulla posuere ullamcorper porta. Maecenas ut leo malesuada, convallis neque ultrices, ultricies lorem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean a erat eu erat posuere adipiscing eget id nisl. Nam eleifend venenatis pharetra. Interdum et malesuada fames ac ante ipsum primis in faucibus. Ut consectet ur lacus sed tellus sodales scelerisque. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Maecenas nec est neque. Nulla quis tortor adipiscing, sodales dui sed, ultrices dolor. Etiam risus arcu, dapibus a libero id, porttitor tempor orci. Nulla et nisi at eros vulputate condimentum auctor in erat. Maecenas adipiscing lorem accumsan velit dignissim ornare. Maecenas lacinia purus nec lorem feugiat dapibus blandit non felis.</p></div>
       <div class="readmore"><a href="#"><img src="images/readmore.png" width="79" height="32" /></a></div>
        </div>
        </div>
        <div class="buttamline"></div>
        
        
    </div>