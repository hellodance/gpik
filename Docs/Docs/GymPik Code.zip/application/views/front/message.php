<div class="clear">&nbsp;</div>
<div>
	<div class="gympik_text"><?php echo $message;?></div>
</div>


