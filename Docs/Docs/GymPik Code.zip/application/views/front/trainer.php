<div class="clear topPad40">&nbsp;</div>
<div class="LeftMenu">
<div class="right-img2">
<div class="rightmenu2">
<h2>10 Reasons to join</h2>
</div>
<div class="benifitnavi2">
<ul>
<li class="line">1. Self branding and Promotion <sup>Absolutely Free!</sup></a></li>
<li style="line-height:25px;">2. Platform to manage existing or <br />&nbsp;&nbsp;&nbsp; new clients<sup>Absolutely Free!</sup></a></li>
<li>3. Enhanced reach for new clients <sup>Absolutely Free!</sup></a></li>
<li>4. More business revenue <sup>Absolutely Free!</sup></a></li>
<li>5. Fill your least popular hours <sup>Absolutely Free!</sup></a></li>
<li style="line-height:25px;">6. Flexibility to choose clients <br />&nbsp;&nbsp;&nbsp; all over India <sup>Absolutely Free!</sup></a></li>
<li>7. No commission</a></li>
<li style="line-height:25px;">8. Access to largest network of fitness <br />&nbsp;&nbsp;&nbsp; professionals <sup>Absolutely Free!</sup></a></li>
<li>9. Manage client progress online <sup>Absolutely Free!</sup></a></li>
<li style="line-height:25px;">10.Complimentary consult from other fitness &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;instructors<sup>Absolutely Free!</sup></a></li>
</ul>
<a href="<?php echo base_url()?>trainer/register" class="button ajaxpop_small" style="float:right; margin:10px 100px;" ><span>REGISTER</span></a>

</div>
</div>
</div>
<div id="txtContainer2" class="gympik_text"  style="text-align:justify" >
	<img src="images/gym2.jpg" heigth="340px" width="340px"style="float:left; margin-right:10px;">
	<p style="padding-left:0px">Whether you are a professional Physical trainer, a Yoga instructor, Dietician, Physiotherapist, Aerobics instructor or Martial Arts guru, GymPik is a right choice for you. GymPik is on a mission to connect users with fitness experts and offer an end-to-end online solution from day-to-day to long term fitness goal. For experts like you, GymPik offers an enhanced network of peers and clients to reach and ofcourse more business opportunities. And all this Absolutely Free! Yes you heard us right; We do not intend to charge a penny from your client engagements.  We do not even process clients’ payment and give you a freedom to negotiate and deal independently! All you need to do is register yourself and manage your clients’ progress at GymPik. We also offer you to invite your existing clienteles on GymPik to manage their workouts and get free consult, if required, from Dietician, Physiotherapist or any other peer specialist.</p>
	
<p>Apart from gaining more business, we also help you to create and promote your brand for life long. What are we looking in for trainers? Qualified/Certified professionals with experience and commitment for change. Register today to experience GymPik difference! </p>
<a href="<?php echo base_url()?>trainer/register" class="button ajaxpop_small" style="float:right;" ><span>REGISTER</span></a>
</div>

<style>

</style>