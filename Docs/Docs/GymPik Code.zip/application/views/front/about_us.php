<link href="<?=base_url()?>css/new/healthify.css" rel="stylesheet" type="text/css">	
<div class="clear topPad40"></div>
<div id="tabs">
<div id="LeftMenu">
	<ul id="menu_about">
	<li style="margin-top:-2px;"><a href="#tabs-1"><img src="<?=base_url()?>images/about-icon.png" height="60" align="absmiddle"> &nbsp;About us</a></li>
	<li><a href="#tabs-2" class="a"><img src="<?=base_url()?>images/team-icon.jpg" height="60" align="absmiddle"> &nbsp;Team</a></li>
	<li><a href="#tabs-3"><img src="<?=base_url()?>images/advice-icon.png" height="60" align="absmiddle"> &nbsp;Advisors</a></li>
	<li><a href="#tabs-4"><img src="<?=base_url()?>images/news-icon.png" height="60" align="absmiddle"> &nbsp;News</a></li>
	<li><a href="#tabs-5"><img src="<?=base_url()?>images/contact-icon.png" height="60" align="absmiddle"> &nbsp;Contact Us</a></li>
	</ul>
</div>
<div id="txtContainer">
	<div id="tabs-1" class="gympik_text">
	<h3>About us</h3>
	<p>Proin elit arcu, rutrum commodo, vehicula tempus, commodo a, risus. Curabitur nec arcu. Donec sollicitudin mi sit amet mauris. Nam elementum quam ullamcorper ante. Etiam aliquet massa et lorem. Mauris dapibus lacus auctor risus. Aenean tempor ullamcorper leo. Vivamus sed magna quis ligula eleifend adipiscing. Duis orci. Aliquam sodales tortor vitae ipsum. Aliquam nulla. Duis aliquam molestie erat. Ut et mauris vel pede varius sollicitudin. Sed ut dolor nec orci tincidunt interdum. Phasellus ipsum. Nunc tristique tempus lectus.</p>
	</div>
	<div id="tabs-2" class="gympik_text">
	<h3>Team</h3>
	<p>Morbi tincidunt, dui sit amet facilisis feugiat, odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie turpis. Sed fringilla, massa eget luctus malesuada, metus eros molestie lectus, ut tempus eros massa ut dolor. Aenean aliquet fringilla sem. Suspendisse sed ligula in ligula suscipit aliquam. Praesent in eros vestibulum mi adipiscing adipiscing. Morbi facilisis. Curabitur ornare consequat nunc. Aenean vel metus. Ut posuere viverra nulla. Aliquam erat volutpat. Pellentesque convallis. Maecenas feugiat, tellus pellentesque pretium posuere, felis lorem euismod felis, eu ornare leo nisi vel felis. Mauris consectetur tortor et purus.</p>
	</div>
	<div id="tabs-3" class="gympik_text">
	<h3>Advisors</h3>
	<p>Mauris eleifend est et turpis. Duis id erat. Suspendisse potenti. Aliquam vulputate, pede vel vehicula accumsan, mi neque rutrum erat, eu congue orci lorem eget lorem. Vestibulum non ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce sodales. Quisque eu urna vel enim commodo pellentesque. Praesent eu risus hendrerit ligula tempus pretium. Curabitur lorem enim, pretium nec, feugiat nec, luctus a, lacus.</p>
	</div>
	<div id="tabs-4" class="gympik_text">
	<h3>News</h3>
	<p>Mauris eleifend est et turpis. Duis id erat. Suspendisse potenti. Aliquam vulputate, pede vel vehicula accumsan, mi neque rutrum erat, eu congue orci lorem eget lorem. Vestibulum non ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce sodales. Quisque eu urna vel enim commodo pellentesque. Praesent eu risus hendrerit ligula tempus pretium. Curabitur lorem enim, pretium nec, feugiat nec, luctus a, lacus.</p>
	</div>
	<div id="tabs-5" class="gympik_text">
	<h3>Contact us</h3>
	<p>Mauris eleifend est et turpis. Duis id erat. Suspendisse potenti. Aliquam vulputate, pede vel vehicula accumsan, mi neque rutrum erat, eu congue orci lorem eget lorem. Vestibulum non ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce sodales. Quisque eu urna vel enim commodo pellentesque. Praesent eu risus hendrerit ligula tempus pretium. Curabitur lorem enim, pretium nec, feugiat nec, luctus a, lacus.</p>
	</div>
</div>	
</div>
<script>
$(function() {
$( "#tabs" ).tabs().addClass( "ui-tabs-vertical ui-helper-clearfix" );
$( "#tabs li" ).removeClass( "ui-corner-top" ).addClass( "ui-corner-left" );
});
</script>

