<?php
/**
 * EApiActiveRecord
 *
 * Add here all API helper functions to be shared among your API models
 *
 * @author Antonio Ramirez <amigo.cobos@gmail.com>
 * @link http://www.ramirezcobos.com/
 * @link http://www.2amigos.us/
 * @copyright 2013 2amigOS! Consultation Group LLC
 * @license http://www.opensource.org/licenses/bsd-license.php New BSD License
 */
class EApiActiveRecord extends EActiveRecord
{

}